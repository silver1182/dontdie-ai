# 股票监控助手 Pro v1.0.0

🚀 24小时自动监控股票行情，止损止盈自动提醒

## ✨ 功能特点

- ⚡ **实时监控** - 每5分钟检查一次股价
- 🚨 **智能预警** - 跌到止损位/涨到止盈位自动通知
- 📊 **盘后报告** - 自动生成今日盈亏总结
- 📱 **多渠道通知** - 支持飞书、邮件、Webhook
- 🔧 **零代码** - 填个配置文件就能跑
- 💻 **跨平台** - Windows/Mac/Linux 都支持

## 📦 文件清单

```
stock-monitor-pro/
├── 📄 README.md                    # 本文件
├── 📘 docs/
│   ├── 安装教程.md                 # 5分钟快速上手
│   └── 配置指南.md                 # 详细配置说明
├── ⚙️ config/
│   └── stocks.json.example         # 股票配置模板
├── 📁 scripts/
│   ├── monitor.js                  # 主监控程序
│   ├── api.js                      # 数据接口
│   ├── alert.js                    # 通知模块
│   └── report.js                   # 报告生成
└── 📦 package.json                 # 依赖配置
```

## 🚀 快速开始

### 1. 安装 Node.js

访问 https://nodejs.org 下载并安装 LTS 版本。

验证安装：
```bash
node -v
npm -v
```

### 2. 安装依赖

```bash
npm install
```

### 3. 配置股票

```bash
# Windows
copy config\stocks.json.example config\stocks.json

# Mac/Linux
cp config/stocks.json.example config/stocks.json
```

编辑 `config/stocks.json`，填入你的股票信息。

### 4. 运行！

```bash
node scripts/monitor.js
```

详细教程请看 `docs/安装教程.md`

## 📱 飞书通知配置

1. 在飞书群中添加「自定义机器人」
2. 复制 Webhook 地址
3. 填入配置文件

详细步骤请看 `docs/安装教程.md` 的「配置飞书通知」章节。

## ⚙️ 配置说明

股票配置示例：
```json
{
  "stocks": [
    {
      "code": "600519",
      "name": "贵州茅台",
      "market": "a",
      "cost": 1500.00,
      "shares": 100,
      "stopLoss": 5,
      "stopGain": 15,
      "notify": true
    }
  ],
  "settings": {
    "checkInterval": 300,
    "notifyChannels": ["feishu"]
  }
}
```

详细配置说明请看 `docs/配置指南.md`

## 🆘 常见问题

**Q: 提示 "node 不是内部或外部命令"？**
A: Node.js 没装好，重新安装并重启电脑。

**Q: 运行后没有数据？**
A: 检查股票代码是否正确，A股不需要加后缀。

**Q: 飞书收不到消息？**
A: 检查 Webhook 地址是否正确。

更多问题请看 `docs/安装教程.md` 的「常见问题」章节。

## 📞 获取帮助

- 飞书：路明非
- 爱发电站内私信

## 📝 更新日志

### v1.0.0 (2026-03-02)
- ✅ 首次发布
- ✅ 支持实时监控和预警
- ✅ 支持飞书/邮件/Webhook通知
- ✅ 支持A股/港股/美股

---

**祝你投资顺利！📈**

*Made with 🌸 by 路明非*
